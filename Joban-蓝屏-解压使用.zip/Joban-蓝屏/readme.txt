部分素材来源于网络。
pokOS-本追加版权所有

以下为ID一览：
bsod_win7  Windows7风格蓝屏（5C报错）
bsod_win19  Windows10风格蓝屏（E2报错）
wnc  永恒之蓝